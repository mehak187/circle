import React from 'react'
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom"; // Import Routes
import Login from "./Login";
import Signup from "./Signup";

function home({loginimg}) {
  return (
    <div>
    </div>
  )
}

export default home